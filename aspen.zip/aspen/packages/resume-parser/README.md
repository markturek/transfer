# @repo/resume-parser

A TypeScript library for parsing resume text and extracting structured information.

## Installation

```bash
npm install @repo/resume-parser
```

## Usage

```typescript
import { parseResume, extractSkills } from '@repo/resume-parser';

const resumeText = `
John Doe
john.doe@example.com
(555) 123-4567

Software Engineer with experience in JavaScript, TypeScript, React, and Node.js
`;

const resume = parseResume(resumeText);
console.log(resume);
// { email: 'john.doe@example.com', phone: '(555) 123-4567', skills: [], ... }

const skills = extractSkills(resumeText);
console.log(skills);
// ['javascript', 'typescript', 'react', 'node.js']
```

## API

### `parseResume(text: string): Resume`

Parses resume text and returns a structured Resume object.

### `extractSkills(text: string): string[]`

Extracts technical skills from resume text.

## Development

```bash
# Build the library
npm run build

# Watch mode
npm run dev

# Type check
npm run check-types

# Lint
npm run lint
```
