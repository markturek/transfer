import type { ResumeSkills } from "../../redux/types";
import type { ResumeSectionToLines } from "../types";
import { deepClone } from "../../deep-clone";
import { getSectionLinesByKeywords } from "./lib/get-section-lines";
import { initialFeaturedSkills } from "../../redux/resumeSlice";
import {
  getBulletPointsFromLines,
  getDescriptionsLineIdx,
} from "./lib/bullet-points";

export const extractSkills = (sections: ResumeSectionToLines) => {
  const lines = getSectionLinesByKeywords(sections, ["skill"]) ?? [];
  const descriptionsLineIdx = getDescriptionsLineIdx(lines) ?? 0;
  const descriptionsLines = lines.slice(descriptionsLineIdx);
  const descriptions = getBulletPointsFromLines(descriptionsLines);

  const featuredSkills = deepClone(initialFeaturedSkills);
  if (descriptionsLineIdx !== 0) {
    const featuredSkillsLines = lines.slice(0, descriptionsLineIdx);
    const featuredSkillsTextItems = featuredSkillsLines
      .flat()
      .filter((item) => item.text.trim())
      .slice(0, 6);
    for (let i = 0; i < featuredSkillsTextItems.length; i++) {
      const featuredSkill = featuredSkills[i];
      const textItem = featuredSkillsTextItems[i];
      if (featuredSkill && textItem) {
        featuredSkill.skill = textItem.text;
      }
    }
  }

  const skills: ResumeSkills = {
    featuredSkills,
    descriptions,
  };

  return { skills };
};
