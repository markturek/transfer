import { configureStore } from "@reduxjs/toolkit";
import resumeReducer from "src/redux/resumeSlice";
import settingsReducer from "src/redux/settingsSlice";

export const store = configureStore({
  reducer: {
    resume: resumeReducer,
    settings: settingsReducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
