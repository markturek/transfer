import { ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

export default function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
export function formatUSPhone(phone: string) {
    // Remove all non-digit characters
    const cleaned = ('' + phone).replace(/\D/g, '');
    // Check for country code
    let number = cleaned;
    if (number.length === 11 && number.startsWith('1')) {
      number = number.slice(1); // Remove leading '1'
      console.log('Removed country code, new number:', number);
    }    
    // Format as (123) 456-7890
    const match = number.match(/^(\d{3})(\d{3})(\d{4})$/);
    console.log('phone', phone);
    console.log('match', match);
    if (match) {
      return `(${match[1]}) ${match[2]}-${match[3]}`;
  }
  return phone;
}

export function remToPx(remValue: number) {
  let rootFontSize =
    typeof window === 'undefined'
      ? 16
      : parseFloat(window.getComputedStyle(document.documentElement).fontSize)

  return remValue * rootFontSize
}
