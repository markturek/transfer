import { z } from 'zod';
import { messages } from '@/lib/messages';
import { validateEmail } from '@/lib/validators';


// generic types and interfaces for the app
export type Nullable<T> = T | null | undefined;

export type UserRole = "admin" | "user" | "guest";

export type DialogComponentProps = {
  isOpen: boolean;
  onClose: () => void;
  onOpen: () => void;
}

// export type Metadata = {
//   Dictionary2<TValue> = { [key: string]: TValue };
// }

export type DocumentInfo = {
  documentId?: string;
  filename: string;
  metadata?: Record<string, unknown>;
  mediaType?: string;
  // Accept browser File/Blob/ArrayBuffer/Uint8Array/ReadableStream and Node Buffer/ReadableStream
  data: File | Blob | ArrayBuffer | Uint8Array | ReadableStream<Uint8Array> | Buffer | NodeJS.ReadableStream;
}

// form zod validation schema
export const createApplicantSchema = z.object({
  tenantId: z.string().optional(),
  firstName: z.string().min(1, { message: messages.firstNameRequired }),
  lastName: z.string().min(1, { message: messages.lastNameRequired }),
  email: validateEmail,
  phone: z.string().min(10, { message: messages.phoneNumberIsRequired }),
  title: z.string().optional(),
  summary: z.string().optional(),
  created: z.date().optional(),
  createdBy: z.string().optional(),
});

// generate form types from zod validation schema
export type CreateApplicant = z.infer<typeof createApplicantSchema>;

export type ApplicantInfo = {
  tenantId: string;
  candidateId: string;
  middleName?: string;
  lastName: string;
  title?: string;
  owner?: string;
  email: string;
  avatar?: string;
  status?: string;
  linkedInId?: string;
  summary?: string;
  phones: Phone[];
  addresses: Address[];
  location?: string;
  created: Date;
};

export type PagedResult<T> = {
  results: T[]
  pageIndex: number;
  pageSize: number;
  pageCount: number;
  totalCount: number;
}

export type PhoneType = "Mobile" | "Home" | "Work"
export type AddressType = "Home" | "Business" | "Billing" | "Shipping"

export type Phone = {
  number: string
  phoneType: PhoneType
}

export type Address = {
  country?: string
  street: string
  city: string
  state: string
  postalCode: string
  addressType: AddressType
}

export type Applicant = {
  tenantId: string
  applicantId?: string
  firstName: string
  middleName?: string
  lastName: string
  email: string
}

// export type UserRole = {
//   tenantId: string
//   name: string

