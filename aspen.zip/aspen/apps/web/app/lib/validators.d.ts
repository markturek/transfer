import { z } from 'zod';
export declare const fileSchema: z.ZodObject<{
    name: z.ZodString;
    url: z.ZodString;
    size: z.ZodNumber;
}, z.core.$strip>;
export type FileSchema = z.infer<typeof fileSchema>;
export declare const validateEmail: z.ZodString;
export declare const validatePassword: z.ZodString;
export declare const validateNewPassword: z.ZodString;
export declare const validateConfirmPassword: z.ZodString;
//# sourceMappingURL=validators.d.ts.map