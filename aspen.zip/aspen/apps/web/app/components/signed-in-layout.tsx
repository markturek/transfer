'use client';

import { StackedLayout } from "@repo/ui/catalyst/stacked-layout";
import { Navbar, NavbarDivider, NavbarItem, NavbarSection, NavbarSpacer } from "@repo/ui/catalyst/navbar";
import { Logo } from "./logo";
import { ThemeToggle } from "./theme-toggle";
import AuthButton from "./auth-button";
import { Sidebar, SidebarBody, SidebarDivider, SidebarItem, SidebarLabel, SidebarSection } from "@repo/ui/catalyst/sidebar";
import { AcademicCapIcon, HomeIcon, Square2StackIcon } from "@heroicons/react/20/solid";
import { usePathname } from "next/navigation";

const topNavItems = [
  { label: 'Features', url: '/features' },
  { label: 'Pricing', url: '/pricing' },
  { label: 'Forums', url: '/forums' },
  { label: 'About Us', url: '/about-us' },
]

const sideNavItems = [
  { label: 'Features', url: '/features' },
  { label: 'Pricing', url: '/pricing' },
  { label: 'Forums', url: '/forums' },
  { label: 'About Us', url: '/about-us' },
]
export function SignedInLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  return (
    <StackedLayout
      navbar={
      <Navbar>
        <Logo />
        <NavbarSpacer />
        <NavbarSection className="max-lg:hidden">
          {topNavItems.map(({ label, url }) => (
            <NavbarItem key={label} href={url} current={pathname === url ? true : false}>
              {label}
            </NavbarItem>
          ))}
        </NavbarSection>                    
        <NavbarSpacer />
        <ThemeToggle />
        <NavbarDivider className="max-lg:hidden" />
        <AuthButton />
      </Navbar>
    }
    sidebar={
      <Sidebar className="bg-gray-50 dark:bg-gray-800 p-2 rounded">
        <SidebarBody>
          <SidebarSection>
            {topNavItems.map(({ label, url }) => (
              <SidebarItem key={label} href={url} current={pathname === url ? true : false}>
                <SidebarLabel>{label}</SidebarLabel>
              </SidebarItem>
            ))}
          </SidebarSection>
          <SidebarDivider />
          <SidebarSection className="lg:hidden">
            <SidebarItem href="/dashboard" current={pathname === "/dashboard" ? true : false}>
              <HomeIcon />
              <SidebarLabel>Dashboard</SidebarLabel>
            </SidebarItem>
            <SidebarItem href="/applicants" current={pathname === "/applicants" ? true : false}>
              <Square2StackIcon />
              <SidebarLabel>Applicants</SidebarLabel>
            </SidebarItem>
              <SidebarItem href="/jobs" current={pathname === "/jobs" ? true : false}>
                <AcademicCapIcon />
                <SidebarLabel>Jobs</SidebarLabel>
              </SidebarItem>            
          </SidebarSection>          
        </SidebarBody>
      </Sidebar>
    }
  >
    <div className="flex flex-col-2 gap-4">
      <div className="max-lg:hidden">
        <Sidebar className="bg-gray-50 dark:bg-gray-800 p-2 rounded">
          <SidebarBody>
            <SidebarSection>
              <SidebarItem href="/dashboard" current={pathname === "/dashboard" ? true : false}>
                <HomeIcon />
                <SidebarLabel>Dashboard</SidebarLabel>
              </SidebarItem>
              <SidebarItem href="/applicants" current={pathname === "/applicants" ? true : false}>
                <Square2StackIcon />
                <SidebarLabel>Applicants</SidebarLabel>
              </SidebarItem>
              <SidebarItem href="/jobs" current={pathname === "/jobs" ? true : false}>
                <AcademicCapIcon />
                <SidebarLabel>Jobs</SidebarLabel>
              </SidebarItem>
            </SidebarSection>
          </SidebarBody>
        </Sidebar>
      </div>
      <div className="w-full">
        {children}
      </div>
    </div>
  </StackedLayout>
);
}