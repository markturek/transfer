import Link from 'next/link'

import { Logo } from '@/components/logo'
// import {
//   MobileNavigation,
//   useIsInsideMobileNavigation,
// } from '@/components/mobile-navigation'
//import { useMobileNavigationStore } from '@/components/mobile-navigation'
import AuthButton from '@/components/auth-button'
import { ThemeToggle } from './theme-toggle'

function TopLevelNavItem({
  href,
  children,
}: {
  href: string
  children: React.ReactNode
}) {
  return (
    <li>
      <Link
        href={href}
        className="text-sm leading-5 text-zinc-600 transition hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-white"
      >
        {children}
      </Link>
    </li>
  )
}

export function Header({ className, ...props }: React.ComponentPropsWithoutRef<'div'>) {

  return (
    <div className='flex border-1'>
      <div className="hidden lg:flex">
        <Logo url="/" />
      </div>
      <div className="flex items-center gap-5 lg:hidden">
        {/* <MobileNavigation /> */}
        <Link href="/" aria-label="Home">
          <Logo />
        </Link>
      </div>
      <div className="flex items-center gap-5 justify-end">
        <nav className="hidden md:block">
          <ul role="list" className="flex items-center gap-8">
            <TopLevelNavItem href="/features">Features</TopLevelNavItem>
            <TopLevelNavItem href="/pricing">Pricing</TopLevelNavItem>
            <TopLevelNavItem href="/forums">Forums</TopLevelNavItem>          
          </ul>
        </nav>
        <div className="hidden md:block md:h-5 md:w-px md:bg-zinc-900/10 md:dark:bg-white/15" />
        <div className="flex gap-4">
          <ThemeToggle />
        </div>
        <div>
          <AuthButton />
        </div>
      </div>
    </div>
  )
}
