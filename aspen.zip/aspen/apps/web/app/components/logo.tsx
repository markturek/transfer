'use client';
import Image from 'next/image';
import TidalForceLogoLight from '@/public/tidal-force-light-logo-600x230.png';
import TidalForceLogoDark from '@/public/tidal-force-dark-logo-600x230.png';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { useTheme } from 'next-themes';

export function Logo({url = "/"}: {url?: string}) {
  const { theme } = useTheme();
  const [mounted, setMounted] = useState(false);

  // Avoid hydration mismatches by rendering a stable logo until mounted
  useEffect(() => {
    setMounted(true);
  }, []);

  const logo = mounted && theme === 'dark' ? TidalForceLogoDark : TidalForceLogoLight;
  return (
    <Link href={url}>
      <Image
        src={logo}
        alt="Home"
        width={100}
        className='rounded-lg'
      />    
    </Link>
  )
}
