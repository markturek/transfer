"use client";
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ModalProvider } from "./modal-provider";
import { ToploaderProvider } from "./toploader-provider";
import React from 'react';

export function Providers({ children }: { children: React.ReactNode }) {
  const [queryClient] = React.useState(() => new QueryClient());
  return (
    <QueryClientProvider client={queryClient}>
      <ToploaderProvider>
        <ModalProvider>
          {children}
        </ModalProvider>
      </ToploaderProvider>
    </QueryClientProvider>
  );
}