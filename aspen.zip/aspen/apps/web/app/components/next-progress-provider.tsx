'use client'
import React, { createContext, useContext } from 'react'
import NextTopLoader from 'nextjs-toploader'
import NProgress from "nprogress"
import 'nprogress/nprogress.css'

type ToploaderContextType = {
  start: () => void
  done: () => void
}

const ToploaderContext = createContext<ToploaderContextType | undefined>(undefined)

export function ToploaderProvider({ children }: { children: React.ReactNode }) {
  const start = () => { NProgress.start() }
  const done = () => { NProgress.done() }

  return (
    <ToploaderContext.Provider value={{ start, done }}>
      <NextTopLoader showSpinner={false} color="#06b6d4" height={3} />
      {children}
    </ToploaderContext.Provider>
  )
}

export function useToploader() {
  const ctx = useContext(ToploaderContext)
  if (!ctx) throw new Error('useToploader must be used within ToploaderProvider')
  return ctx
}