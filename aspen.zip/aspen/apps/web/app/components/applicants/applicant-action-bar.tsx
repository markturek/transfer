'use client';
import { Button } from "@repo/ui/catalyst/button";
import { PlusIcon, SparklesIcon } from "@heroicons/react/20/solid";
import { useModal } from "../modal-provider";

export function ApplicantActionBar() {
  const modalCtx = useModal();
  return (
    <div className="flex justify-left gap-2 bg-gray-50 dark:bg-gray-800 p-2 rounded">
      <Button plain onClick={() => modalCtx.open()}><PlusIcon />Add Applicant</Button>
      <Button plain><SparklesIcon />Parse Resume</Button>
    </div>
  );
}
