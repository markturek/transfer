import { getApplicants } from "@/actions/applicant-actions";
import { useQuery } from "@tanstack/react-query";

export function useApplicants(tenantId: string, page: number, pageSize: number) {
  return useQuery({
    queryKey: ['applicants', tenantId, page, pageSize],
    queryFn: () => getApplicants(tenantId, page, pageSize),
    placeholderData: (previousData) => previousData
  });
}