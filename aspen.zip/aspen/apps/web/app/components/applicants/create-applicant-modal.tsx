'use client'

import { PlusIcon } from "@heroicons/react/16/solid";
import { Button } from "@repo/ui/catalyst/button";
import { Dialog, DialogActions, DialogBody, DialogTitle } from "@repo/ui/catalyst/dialog";
import { ErrorMessage, Field, Label } from "@repo/ui/catalyst/fieldset";
import { Input } from "@repo/ui/catalyst/input";
import { Controller, SubmitHandler, useForm } from "react-hook-form";
import { CreateApplicant, createApplicantSchema, DialogComponentProps } from "@/types";
import { zodResolver } from "@hookform/resolvers/zod";
import { Combobox, ComboboxLabel, ComboboxOption } from "@repo/ui/catalyst/combobox";
import { useUser } from "@clerk/nextjs";
import { createApplicant } from "@/actions/applicant-actions";
import { SimpleFileInput } from "../simple-file-input";
import { useModal } from "../modal-provider";

  const titles: string[] = [
    "Software developer/engineer", 
    "Web developer", 
    "Mobile app developer", 
    "Game developer",
    "Full-stack developer",
    "Quality assurance",
    "User experience (UX) designer"
  ];

export function CreateApplicantModal() {
  const { isSignedIn, user } = useUser();
  const modalCtx = useModal();

  const { handleSubmit, control, register, formState: { errors, isValid } } = useForm<CreateApplicant>({
    resolver: zodResolver(createApplicantSchema),
  })  

const onSubmit: SubmitHandler<CreateApplicant> = async (data: CreateApplicant) => {
    data.tenantId = user?.unsafeMetadata?.domain as string | undefined;
    let id = '';
    data.createdBy = user?.id!;
    data.created = new Date();
    let res = await createApplicant(data);
  };

  return (
    <>
      <form id="create-applicant-form" onSubmit={handleSubmit(onSubmit, (errors) => console.log('Validation failed:', errors))}>
        <Dialog open={modalCtx.isOpen} onClose={modalCtx.close}>
          <DialogTitle>Create Applicant</DialogTitle>
          <DialogBody>
            <Field className="mb-2">
              <Label>Title</Label>
              <Controller
                name="title"
                control={control}
                render={({ field: { onChange, value } }) => (
                  <Combobox
                    placeholder="Select title&hellip;"
                    options={titles}
                    displayValue={(title) => title ?? undefined}
                    aria-label="Title"
                    value={value ?? ""}
                    onChange={onChange}
                  >
                    {(title) => (
                      <ComboboxOption value={title}>
                        <ComboboxLabel>{title}</ComboboxLabel>
                      </ComboboxOption>
                    )}
                  </Combobox>
                )}
              />
            </Field>
            <Field className="mb-2">
              <Label>First Name</Label>
              <Input 
                className="mt-0"
                placeholder="Enter your first name" 
                {...register('firstName')} 
                invalid={errors.firstName != undefined}  />
                {<ErrorMessage>{errors.firstName?.message}</ErrorMessage>}
            </Field>
            <Field className="mb-2">
              <Label>Last Name</Label>
              <Input placeholder="Enter your last name" {...register('lastName')} 
              invalid={errors.lastName != undefined}/>
              {<ErrorMessage>{errors.lastName?.message}</ErrorMessage>}
            </Field>
            <Field className="mb-2">
              <Label>Email</Label>
              <Input placeholder="Enter your email" type="email" {...register('email')} 
              invalid={errors.email != undefined} />
              {<ErrorMessage>{errors.email?.message}</ErrorMessage>}
            </Field>
            <Field className="mt-2">
              <Label>Phone</Label>
              <Input placeholder="Enter your phone" type="tel" {...register('phone')} 
              invalid={errors.phone != undefined} />
              {<ErrorMessage>{errors.phone?.message}</ErrorMessage>}
            </Field>
            <Field className="mt-2">
              <Label>Resume</Label>
              <SimpleFileInput />          
            </Field>
          </DialogBody>
          <DialogActions>
            <Button plain onClick={() => modalCtx.close()}>
              Cancel
            </Button>
            <Button type="submit" form="create-applicant-form">Submit</Button>
          </DialogActions>
        </Dialog>      
      </form>
    </>
  )
} 