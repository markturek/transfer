'use client';
import { Avatar } from '@repo/ui/catalyst/avatar'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@repo/ui/catalyst/table'
import { formatUSPhone } from '@repo/utils';
import { Pagination, PaginationList, PaginationNext, PaginationPage, PaginationPrevious } from '@repo/ui/catalyst/pagination';
import { useApplicants } from './use-applicants';

export function ApplicantTable() {
  // Read page from search params (default to 1)
  const searchParams = (typeof window === "undefined")
    ? new URLSearchParams(require('next/headers').headers().get('x-next-url')?.split('?')[1] || '')
    : new URLSearchParams(window.location.search);
  const page = parseInt(searchParams.get('page') || '1', 10);
  const pageSize = 10;

  //const user = await currentUser();
  const { data, isLoading, error } = useApplicants('lunartide.net', page, pageSize);

  function getInitials(firstName: string, lastName: string) {
    if (!firstName || !lastName) return '';
    return firstName.charAt(0) + lastName.charAt(0);
  }

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (error || !data) {
    return <div>Error loading applicants.</div>;
  }

  return (
    <div>
      <Table dense className="[--gutter:--spacing(6)] sm:[--gutter:--spacing(8)]">
        <TableHead>
          <TableRow>
            <TableHeader>Name</TableHeader>
            <TableHeader>Title</TableHeader>
            <TableHeader>Phone</TableHeader>
            <TableHeader>Owner</TableHeader>
            <TableHeader>Status</TableHeader>
          </TableRow>
        </TableHead>
        <TableBody>
          {data.results?.map((user: any) => (
            <TableRow key={user.applicantId}>
              <TableCell>
                <div className="flex items-center gap-4">
                  <Avatar src={user.avatarUrl} initials={getInitials(user.firstName, user.lastName)} className="size-8" />
                  <div>
                    <div className="font-medium">{user.firstName + '  ' + user.lastName}</div>
                    <div className="text-zinc-500">
                      <a href="#" className="hover:text-zinc-700">
                        {user.email}
                      </a>
                    </div>
                  </div>
                </div>
              </TableCell>
              <TableCell className="text-zinc-500">{user.title}</TableCell>
              <TableCell className="text-zinc-500">{user.phones?.length > 0 ? formatUSPhone(user.phones[0].number) : ''}</TableCell>
              <TableCell className="text-zinc-500">{user.owner}</TableCell>
              <TableCell>
                {user.status}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <Pagination className="mt-6">
        <PaginationPrevious href={`?page=${Math.max(1, page - 1)}`} disabled={page <= 1} />
        <PaginationList>
          {Array.from({ length: data.pageCount }, (_, i) => (
            <PaginationPage
              key={i + 1}
              href={`?page=${i + 1}`}
              current={page === i + 1}
            >
              {i + 1}
            </PaginationPage>
          ))}
        </PaginationList>
        <PaginationNext href={`?page=${Math.min(data.pageCount, page + 1)}`} disabled={page >= data.pageCount} />
      </Pagination>
    </div>
  )
}