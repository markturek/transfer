// Import runtime values
import clsx from 'clsx';

// Import only types
import { type Ref, type ElementType, useState, useRef } from 'react';
import { Button } from '@repo/ui/catalyst/button';

export interface FileInputProps 
extends Omit<React.HTMLAttributes<HTMLElement>, 'size' | 'type'>
{
  placeholder?: string;
  className?: string;
  inputRef?: Ref<HTMLInputElement>;
  buttonLabel?: string;
};

export function SimpleFileInput({
  placeholder,
  className,
  inputRef,
  buttonLabel = 'Select File',
}: FileInputProps) {
  const [fileName, setFileName] = useState('');
  const fileInputRef: Ref<HTMLInputElement> = useRef(null);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFileName(file.name);
    }
  };

  const Component: ElementType = 'span';
  return (
    <Component
      data-slot="control"
      className={clsx([
        className,
        // Basic layout
        'relative block w-full',
        // Background color + shadow applied to inset pseudo element, so shadow blends with border in light mode
        'before:absolute before:inset-px before:rounded-[calc(var(--radius-lg)-1px)] before:bg-blue before:shadow-sm dark:border-white/10',
        // Background color is moved to control and shadow is removed in dark mode so hide `before` pseudo
        'dark:before:hidden',
        // Focus ring
        'after:pointer-events-none after:absolute after:inset-0 after:rounded-lg after:ring-transparent after:ring-inset sm:focus-within:after:ring-2 sm:focus-within:after:ring-blue-500',
        // Disabled state
        'has-data-disabled:opacity-50 has-data-disabled:before:bg-zinc-950/5 has-data-disabled:before:shadow-none',
      ])}
    >
    <input
      ref={fileInputRef}
      placeholder={placeholder}
      className="hidden"
      type="file"
      onChange={handleFileChange}
    />
    <Button
      onClick={() => {
        if (fileInputRef && 'current' in fileInputRef && fileInputRef.current) {
          fileInputRef.current.click();
        }
      }}
      >{buttonLabel}
    </Button>
    <span className='p-1 dark:text-white'>{fileName}</span>

    </Component>
  );
}
