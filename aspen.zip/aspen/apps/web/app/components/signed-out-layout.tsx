import { Navbar, NavbarDivider, NavbarItem, NavbarSection, NavbarSpacer } from "@repo/ui/catalyst/navbar";
import { Logo } from "./logo";
import { ThemeToggle } from "./theme-toggle";
import AuthButton from "./auth-button";
import { Sidebar, SidebarBody, SidebarItem, SidebarLabel, SidebarSection } from "@repo/ui/catalyst/sidebar";
import { StackedLayout } from "@repo/ui/catalyst/stacked-layout";


const navItems = [
  { label: 'Features', url: '/features' },
  { label: 'Pricing', url: '/pricing' },
  { label: 'Forums', url: '/forums' },
  { label: 'About Us', url: '/about-us' },
]

export function SignedOutLayout({ children }: { children: React.ReactNode }) {
  return (
    <StackedLayout navbar={
      <Navbar>
        <Logo />
        <NavbarSpacer />
        <NavbarSection className="max-lg:hidden">
          {navItems.map(({ label, url }) => (
            <NavbarItem key={label} href={url}>
              {label}
            </NavbarItem>
          ))}
        </NavbarSection>                    
        <NavbarSpacer />
        <ThemeToggle />
        <NavbarDivider className="max-lg:hidden" />
        <AuthButton />
      </Navbar>
      }
      sidebar={
        <Sidebar>
          <SidebarBody>
            <SidebarSection>
              {navItems.map(({ label, url }) => (
                <SidebarItem key={label} href={url}>
                  <SidebarLabel>{label}</SidebarLabel>
                </SidebarItem>
              ))}
            </SidebarSection>
          </SidebarBody>
        </Sidebar>
        }>{children}
    </StackedLayout>
)
}