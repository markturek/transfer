'use client'

import React from 'react'
import { SignedOut, SignedIn, useClerk } from '@clerk/nextjs';
import { redirect } from 'next/navigation'
import { Button } from '@repo/ui/catalyst/button';

export default function AuthButton() {

  const { signOut } = useClerk();

  return (
    <>
      <SignedIn>
        <Button onClick={() => signOut({ redirectUrl: '/' })}>Sign out</Button>
      </SignedIn>
      <SignedOut>
        <Button onClick={() => redirect('/sign-in')}>Sign in</Button>
      </SignedOut>
    </>
  )
}

