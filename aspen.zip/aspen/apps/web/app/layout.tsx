import "./globals.css";
import "@repo/ui/styles.css";
import { ClerkProvider, SignedOut, SignedIn } from "@clerk/nextjs";
import type { Metadata } from "next";
import { Geist } from "next/font/google";
import localFont from "next/font/local";
import Script from "next/script";
import { SignedOutLayout } from "./components/signed-out-layout";
import { SignedInLayout } from "./components/signed-in-layout";
import { Providers } from "./components/providers";
import { ThemeProvider } from "./components/theme-provider";
const geist = Geist({ subsets: ["latin"] });

export const metadata: Metadata = {
  metadataBase: new URL("https://clerk-next-app.vercel.app/"),
  title: "Next.js Clerk Template",
  description:
    "A simple and powerful Next.js template featuring authentication and user management powered by Clerk.",
  openGraph: { images: ["/og.png"] },
};

const geistSans = localFont({
  src: "./fonts/GeistVF.woff",
  variable: "--font-geist-sans",
});

const geistMono = localFont({
  src: "./fonts/GeistMonoVF.woff",
  variable: "--font-geist-mono",
});



export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${geistSans.variable} ${geistMono.variable} h-full`} suppressHydrationWarning>
      <ClerkProvider
        appearance={{
          variables: { colorPrimary: "#000000" },
          elements: {
            formButtonPrimary:
              "bg-black border border-black border-solid hover:bg-white hover:text-black",
            socialButtonsBlockButton:
              "bg-white border-gray-200 hover:bg-transparent hover:border-black text-gray-600 hover:text-black",
            socialButtonsBlockButtonText: "font-semibold",
            formButtonReset:
              "bg-white border border-solid border-gray-200 hover:bg-transparent hover:border-black text-gray-500 hover:text-black",
            membersPageInviteButton:
              "bg-black border border-black border-solid hover:bg-white hover:text-black",
            card: "bg-[#fafafa]",
          },
        }}
      >
        <body className={`min-h-full antialiased`}>
          <ThemeProvider>
            <div className="w-full">
              <Providers>
                <SignedIn>
                  <SignedInLayout children={children} />
                </SignedIn>
                <SignedOut>
                  <SignedOutLayout children={children} />
                </SignedOut>
              </Providers>
            </div>
          </ThemeProvider>
        </body>
      </ClerkProvider>
    </html>
  );
}
