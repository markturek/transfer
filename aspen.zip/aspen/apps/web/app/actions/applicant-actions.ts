'use server'

import { fetchWrapper } from "./fetch-wrapper";
import { ApplicantInfo, CreateApplicant, PagedResult } from "@/types";
import { revalidatePath } from "next/cache";

export async function createApplicant(data: CreateApplicant) {
  const result = await fetchWrapper.post('/api/applicant', data);
  revalidatePath('/applicants');
  return result;
}

export async function getApplicants(tenantId: string, page: number, pageSize: number): Promise<PagedResult<ApplicantInfo>> {
  return await fetchWrapper.get(`/api/applicant/applicants/${tenantId}/${page}/${pageSize}`);
}

 