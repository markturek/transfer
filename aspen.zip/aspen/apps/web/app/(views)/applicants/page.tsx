import { ApplicantTable } from "@/components/applicants/applicant-table"
import { CreateApplicantModal } from "@/components/applicants/create-applicant-modal"
import { ApplicantActionBar } from "@/components/applicants/applicant-action-bar"
import { currentUser } from '@clerk/nextjs/server';

const users = [
  { applicantId: 1, name: 'Lindsay Walton', title: 'Front-end Developer', initials: 'LW', email: 'lindsay.walton@example.com', status: 'Member' },
  { applicantId: 2, name: 'Courtney Henry', title: 'Designer', email: 'courtney.henry@example.com', status: 'Admin' },
  { applicantId: 3, name: 'Tom Cook', title: 'Director of Product', email: 'tom.cook@example.com', status: 'Member' },
  { applicantId: 4, name: 'Whitney Francis', title: 'Copywriter', email: 'whitney.francis@example.com', status: 'Admin' },
  { applicantId: 5, name: 'Leonard Krasner', title: 'Senior Designer', email: 'leonard.krasner@example.com', status: 'Owner' },
  { applicantId: 6, name: 'Floyd Miles', title: 'Principal Designer', email: 'floyd.miles@example.com', status: 'Member' },
]
export default async function Page() {
  const user = await currentUser();
  return (
    <div>
      <ApplicantActionBar />
      <CreateApplicantModal />
      <div className="mt-2 flow-root">
        <div className="overflow-x-auto">
          <div className="inline-block min-w-full py-2 align-middle">
            <ApplicantTable />
          </div>
        </div>
      </div>
    </div>
  )
}
